
import React, { useState } from 'react';

function App() {
  const [sku, setSku] = useState('');
  const [result, setResult] = useState(null);

  const handleLaunch = () => {
    // 模拟启动 Agent 协同
    setResult({ status: 'Processing', steps: ['Insight Agent Active', 'Copywriting...'] });
    setTimeout(() => {
      setResult({
        status: 'Completed',
        content: 'Premium Eco-Friendly Product for NY Market',
        compliance: 'Passed: 100%'
      });
    }, 3000);
  };

  return (
    <div style={{ padding: '40px', fontFamily: 'sans-serif' }}>
      <h1>Global AI Content Studio</h1>
      <textarea 
        placeholder="Enter SKU Details..." 
        value={sku} 
        onChange={(e) => setSku(e.target.value)}
        style={{ width: '100%', height: '100px', marginBottom: '20px' }}
      />
      <button onClick={handleLaunch} style={{ padding: '10px 20px', background: '#007bff', color: '#fff', border: 'none', borderRadius: '5px' }}>
        启动多 Agent 营销管线
      </button>

      {result && (
        <div style={{ marginTop: '20px', padding: '20px', border: '1px solid #ccc' }}>
          <h3>工作流状态: {result.status}</h3>
          <p>{result.content}</p>
          <small style={{ color: 'green' }}>{result.compliance}</small>
        </div>
      )}
    </div>
  );
}
export default App;
